package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.Model.Airplane;
import com.Repostory.AirlineRepository;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/air")
public class AirplaneController {
	
	@Autowired
	AirlineRepository airrepo;
	 
	
	@GetMapping("/airdetails")
	public ResponseEntity<List<Airplane>> getDetails(){
		List<Airplane> list=airrepo.findAll();
		return new ResponseEntity<List<Airplane>>(list, HttpStatus.OK);
	}
	@GetMapping("/airdetails/{flightid}")
	public ResponseEntity<Airplane> getDetailsById(@PathVariable("flightid") int flightid){
		Airplane air=airrepo.findById(flightid).get();
		return new ResponseEntity<Airplane>(air, HttpStatus.OK);
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/airdetails")
	public ResponseEntity<Airplane> postAirDetails(@RequestBody @Valid  Airplane airplane){
//		Airplane air=new Airplane();
//		air.setFlightname(airplane.getFlightname());
//		air.setOrigin(airplane.getOrigin());
//		air.setDestination(airplane.getDestination());
//		air.setDateofarrival(airplane.getDateofarrival());
//		air.setDateofdept(airplane.getDateofdept());
//		air.setPriceforeconomyclass(airplane.getPriceforeconomyclass());
//		air.setPriceforbussinessclass(airplane.getPriceforbussinessclass());
//		airrepo.save(air);
	return new ResponseEntity<Airplane>(airrepo.save(airplane),HttpStatus.CREATED);
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/airdetails/{flightid}")
	public ResponseEntity<Airplane> updateAirDetails(@PathVariable("flightid")int flightid,@RequestBody @Valid  Airplane airplane){
		
		Airplane air=airrepo.findById(flightid).get();
		air.setFlightname(airplane.getFlightname());
		air.setOrigin(airplane.getOrigin());
		air.setDestination(airplane.getDestination());
		air.setDateofarrival(airplane.getDateofarrival());
		air.setDateofdept(airplane.getDateofdept());
		air.setPriceforeconomyclass(airplane.getPriceforeconomyclass());
		air.setPriceforbussinessclass(airplane.getPriceforbussinessclass());
		airrepo.save(air);
		return new ResponseEntity<Airplane>(air, HttpStatus.CREATED);
		}
	
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/airdetails/{flightid}")
	public ResponseEntity<Airplane> DeleteAirDetails(@PathVariable("flightid") int flightid){
//		airrepo.deleteById(flightid);
		Airplane air=airrepo.findById(flightid).get();
		airrepo.deleteById(flightid);
		return new ResponseEntity<Airplane>(air, HttpStatus.OK);
	}
	@GetMapping("/airdetail/{origin}/{destination}")
	public ResponseEntity<List<Airplane>> getByOtoD(@PathVariable String origin,@PathVariable String destination){
		List<Airplane> air=airrepo.findByOriginAndDestination(origin, destination);
		return new ResponseEntity<List<Airplane>>(air,HttpStatus.OK);
				
		
	}
	@GetMapping("/airdetail/{dateofdept}")
	public ResponseEntity<List<Airplane>> getByDate(@PathVariable String dateofdept){
		return new ResponseEntity<List<Airplane>>(airrepo.findByDateofdept(dateofdept),HttpStatus.OK);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> AirplaneHandler(MethodArgumentNotValidException ex) {
		Map<String, String> map=new HashMap<String, String>();
		ex.getBindingResult().getFieldErrors().forEach(e->{
			map.put(e.getField(), e.getDefaultMessage());
		});
		return map;
		
	}
	
	
	
	
	
	

}

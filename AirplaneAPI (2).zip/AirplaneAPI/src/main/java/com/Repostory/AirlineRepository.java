package com.Repostory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Model.Airplane;

public interface AirlineRepository extends JpaRepository<Airplane, Integer>{
	
	public List<Airplane> findByOriginAndDestination(String origin, String destination);
	
	public List<Airplane> findByDateofdept(String dateofdept);

}

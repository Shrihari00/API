package com.Model;

import org.springframework.web.bind.annotation.RestController;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@RestController
@Entity
@Table(name="AirplaneDetails")
public class Airplane {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int flightid;
	@NotBlank(message="notblank")
	private String flightname;
	@NotBlank(message="notblank")
	String origin;
	@NotBlank(message="notblank")
	private String destination;
	@NotBlank(message="notblank")
	private String dateofdept;
	@NotBlank(message="notblank")
	private String dateofarrival;
	@NotNull(message="notnull")
	private double priceforeconomyclass;
	@NotNull(message="notnull")
	private double priceforbussinessclass;
	public int getFlightid() {
		return flightid;
	}
	public void setFlightid(int flightid) {
		this.flightid = flightid;
	}
	public String getFlightname() {
		return flightname;
	}
	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDateofdept() {
		return dateofdept;
	}
	public void setDateofdept(String dateofdept) {
		this.dateofdept = dateofdept;
	}
	public String getDateofarrival() {
		return dateofarrival;
	}
	public void setDateofarrival(String dateofarrival) {
		this.dateofarrival = dateofarrival;
	}
	public double getPriceforeconomyclass() {
		return priceforeconomyclass;
	}
	public void setPriceforeconomyclass(double priceforeconomyclass) {
		this.priceforeconomyclass = priceforeconomyclass;
	}
	public double getPriceforbussinessclass() {
		return priceforbussinessclass;
	}
	public void setPriceforbussinessclass(double priceforbussinessclass) {
		this.priceforbussinessclass = priceforbussinessclass;
	}
	@Override
	public String toString() {
		return "Airplane [flightid=" + flightid + ", flightname=" + flightname + ", origin=" + origin + ", destination="
				+ destination + ", dateofdept=" + dateofdept + ", dateofarrival=" + dateofarrival
				+ ", priceforeconomyclass=" + priceforeconomyclass + ", priceforbussinessclass="
				+ priceforbussinessclass + "]";
	}
	public Airplane(int flightid, String flightname, String origin, String destination, String dateofdept,
			String dateofarrival, double priceforeconomyclass, double priceforbussinessclass) {
		super();
		this.flightid = flightid;
		this.flightname = flightname;
		this.origin = origin;
		this.destination = destination;
		this.dateofdept = dateofdept;
		this.dateofarrival = dateofarrival;
		this.priceforeconomyclass = priceforeconomyclass;
		this.priceforbussinessclass = priceforbussinessclass;
	}
	public Airplane() {
		super();
	}
	
//	<dependency>
//	<groupId>org.springframework.boot</groupId>
//	<artifactId>spring-boot-starter-security</artifactId>
//</dependency>
	
	
	
}

package com.citiustech;

public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
@FunctionalInterface
interface MyFunctionalInterface{
	public void display();
	
	default void hello() {
		
	}
	static void hello2() {
		
	}
}
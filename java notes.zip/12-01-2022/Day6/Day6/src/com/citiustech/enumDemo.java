package com.citiustech;

public class enumDemo {
	enum months{JANUARY,FEBRUARY,MARCH;}

	public static void main(String[] args) {
		for(months m: months.values()) {
			System.out.println(m);
		}
		System.out.println("January at the index"+months.valueOf("JANUARY"));
		System.out.println("January at the index"+months.valueOf("FEBRUARY").ordinal());
		

	}

}

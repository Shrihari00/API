package com.citiustech;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MyReflectionDemo {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
		// MyReflect Class object created
		MyReflect obj = new MyReflect();
		Class cls = obj.getClass();
		// Getting information about MyReflect class
		System.out.println(cls);
		System.out.println(cls.getName());

		// getting constructor of the class using object of object class
		Constructor constructor = cls.getConstructor();
		System.out.println(constructor.getName());

		System.out.println("---------Methods Name-----");
		// getting method information
		Method[] method = cls.getMethods();
		for (Method mt : method) {
			System.out.println("Method Name =" + mt.getName());
		}
		System.out.println("-----------------------");
		// create object of desired methods

		Method callMethod2 = cls.getDeclaredMethod("method2", int.class);
		callMethod2.invoke(obj, 305);

		// create an object for accessing empName
		Field field = cls.getDeclaredField("empName");
		field.setAccessible(true);
		// setting the value to private field of class
		field.set(obj, "Core Java Training");

		// creating object for method 1
		Method callMethod1 = cls.getDeclaredMethod("method1");
		callMethod1.invoke(obj);

		Method callMethod3 = cls.getDeclaredMethod("method3");

		callMethod3.setAccessible(true);

		callMethod3.invoke(obj);

	}

}

class MyReflect {
	// private String object
	final String empName;
	

	// public constructor
	public MyReflect() {
		empName = "Athena Freshers";
	}

	public void method1() {
		System.out.println("Emp Name = " + empName);
	}

	public void method2(int eid) {
		System.out.println("Emp ID =" + eid);
	}

	private void method3() {
		System.out.println("This is my private method");
	}
}

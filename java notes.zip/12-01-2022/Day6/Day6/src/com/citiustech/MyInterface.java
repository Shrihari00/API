package com.citiustech;

public interface MyInterface {

	public void displayMessage() ;
}
class MyClass implements MyInterface{

	@Override
	public void displayMessage() {
		
		
	}
	
	
}

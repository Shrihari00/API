package com.citiustech;

public enum SocialAwarenessApplication {
POLICE(100),AMBULANCE(101),FIRE(108);
	int contatNumber;
	SocialAwarenessApplication(int contatNumber){
		this.contatNumber=contatNumber;
	}
	public static void main(String[] args) {
		System.out.println("Police Emergency Contact ="+SocialAwarenessApplication.POLICE.contatNumber);
	}
}
//Class Assignment
//two enums 
//1. Mobile {iphone12(50000), Iphonne13(60000), Oppo12}
//2. Laptop


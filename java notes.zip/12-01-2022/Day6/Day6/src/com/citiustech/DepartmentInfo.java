package com.citiustech;

public enum DepartmentInfo {
HR("Human Resource"),FINANCE("Accounts Related"),SERVICE("After sale"),DISPATCH("Dispatch");
	String dName;
	DepartmentInfo(String dName){
		this.dName=dName;
	}
	public static void main(String[] args) {
		System.out.println("HR Department Stand for ="+DepartmentInfo.valueOf("HR").dName);
	}
}


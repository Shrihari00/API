package com.citiustech;

import com.citiustech.enumDemo.months;

public class MyProducts {
	public enum mobile{
		IPHONE12(50000),IPHONE13PRO(60000);
		int value;
		mobile(int value){
			this.value=value;
		}
	}
	public static void main(String[] args) {
//		System.out.println("Price of Iphone 12 ="+mobile.IPHONE12.value);
		for(Mobile m: Mobile.values()) {
			System.out.println(m);
		}

	}
	public void hello() {
		
	}
}

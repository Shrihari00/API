package com.citiustech;

import java.util.ArrayList;

public class SupressWarningDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		@SuppressWarnings("rawtypes")
		ArrayList list = new ArrayList();
		list.add("Bhushan");
		list.add(12345);
		Parent obj = new Parent();
		obj.myMethod1();

	}

}

class Parent {
	
	@Deprecated
	public void myMethod1() {
		System.out.println("Hello This is Deprecated Method Please Don't use it");

	}
	public void myMethod2() {

	}

}

class Child {
	public void myMethod1() {

	}
	public void myMethod2() {

	}

}

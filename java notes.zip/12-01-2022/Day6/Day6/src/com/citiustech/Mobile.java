package com.citiustech;

public enum Mobile {
IPHONE12, IPHONE13
}

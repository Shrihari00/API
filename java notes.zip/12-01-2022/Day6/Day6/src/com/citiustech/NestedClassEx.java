package com.citiustech;

public class NestedClassEx {

	public static void main(String[] args) {
		Outer obj = new Outer();
		Outer.Inner innerObj = new Outer.Inner();
		innerObj.display();

	}

}

class Outer {
	static int eId = 10;
	int eId1 = 12;
	private static int eId2 = 23;

	static class Inner {

		void display() {
			System.out.println(eId);
			System.out.println(eId2);
			// System.out.println(eId1);
		}

	}
}

//// how to access inner classes
//// Create object of Outer class
//Outer outerObj = new Outer();
//// using outer class object I am accessing inner class
//Outer.Inner innerObj = outerObj.new Inner();
//innerObj.displayInnerMessage();
////Can I declare class as static ?
////inner class
//class Outer {
//	static int eId = 10;
//	int eid2 = 20;
//
//	public void displayOuterMessage() {
//		System.out.println("This is Method from Outer Class");
//	}
//
//	class Inner {
//
//		public void displayInnerMessage() {
//			System.out.println("This is Method from Inner Class");
//			System.out.println("Employee ID" + eId);
//			System.out.println(eid2);
//		}
//
//	}
//}

package com.citiustech;

public class AnnonymousDemo {

	public static void main(String[] args) {
		//creating object of MyAnnonClass
		MyAnnonClass obj = new MyAnnonClass() {
			public void displayMessage() {
				System.out.println("Bye Bye");
			}
			public void myName() {
				System.out.println("Athena Freshers");
			}
		};
		obj.displayMessage();
		

	}

}
class MyAnnonClass{
	public void displayMessage() {
		System.out.println("Hello There");
	}

}


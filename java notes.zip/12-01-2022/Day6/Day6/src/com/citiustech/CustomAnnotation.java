package com.citiustech;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;

public class CustomAnnotation {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException  {
		Hello obj = new Hello();
		Method m = obj.getClass().getMethod("sayHello");
		
		MyAnnotation myAnnotation = m.getAnnotation(MyAnnotation.class);
		
		System.out.println("My Annotation Value ="+myAnnotation.value());
	

	}

}

//create annotation
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface MyAnnotation {
	int value();
}

//Applying this MyAnnotation
class Hello {
	@MyAnnotation(value = 10)
	public void sayHello() {
		System.out.println("Applying My Annotation");
	}

}
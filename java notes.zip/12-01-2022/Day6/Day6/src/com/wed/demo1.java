package com.wed;



enum days{
	MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY
}
public class demo1 {
	public static void main(String[] args) {
		for(days d:days.values()) {
			System.out.println(d);
		}
		System.out.println("Monday at the index"+days.valueOf("MONDAY").ordinal());
		System.out.println("Tuesday at the index"+days.valueOf("TUESDAY").ordinal());
	}

}

package com.wed;


public enum Demo3MyDept {
	HR("Human Resource"),FINANCE("Accounts Related"),SERVICE("After sale"),DISPATCH("Dispatch");
	String dName;
	Demo3MyDept(String dName){
		this.dName=dName;
	}
	public static void main(String[] args) {
		System.out.println("HR Department Stand for ="+Demo3MyDept.valueOf("HR").dName);
	}
}

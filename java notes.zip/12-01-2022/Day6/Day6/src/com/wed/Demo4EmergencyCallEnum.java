package com.wed;



public enum Demo4EmergencyCallEnum {
	POLICE(100),AMBULANCE(101),FIRE(108);
	int contatNumber;
	Demo4EmergencyCallEnum(int contatNumber){
		this.contatNumber=contatNumber;
	}

	public static void main(String[] args) {
		System.out.println("Police Emergency Contact ="+Demo4EmergencyCallEnum.POLICE.contatNumber);

	}

}

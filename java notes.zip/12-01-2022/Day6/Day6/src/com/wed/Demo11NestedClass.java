package com.wed;

public class Demo11NestedClass {

	public static void main(String[] args) {
		Outer outerObj = new Outer();
		Outer.Inner innerObj = outerObj.new Inner();
		innerObj.displayInnerMessage();
	}
}
class Outer {
	static int eId = 10;
	int eid2 = 20;
	public void displayOuterMessage() {
		System.out.println("This is Method from Outer Class");
	}
	class Inner {
	public void displayInnerMessage() {
			System.out.println("This is Method from Inner Class");
			System.out.println("Employee ID" + eId);
			System.out.println(eid2);
		}
	}
}

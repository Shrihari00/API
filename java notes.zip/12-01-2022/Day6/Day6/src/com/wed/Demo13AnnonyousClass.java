package com.wed;


public class Demo13AnnonyousClass {

	public static void main(String[] args) {
		MyAnnonClass obj = new MyAnnonClass() {
			public void displayMessage() {
				System.out.println("Hello");
			}
		};
		obj.displayMessage();
	}
}
class MyAnnonClass{
	public void displayMessage() {
		System.out.println("Hello There");
	}

}

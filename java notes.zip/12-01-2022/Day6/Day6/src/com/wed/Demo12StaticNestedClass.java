package com.wed;

public class Demo12StaticNestedClass {

	public static void main(String[] args) {
		Outer1.Inner obj = new Outer1.Inner();
		obj.display();	
	}
}
class Outer1 {
	static int eId = 10;
	int eId1 = 12;
	private static int eId2 = 23;
	static class Inner {
		 void display() {
			System.out.println(eId);
			System.out.println(eId2);
//			System.out.println(eId1);
		 }
	}
}
package com.wed;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

public class Demo8TargetAnnotation {

	@Target(ElementType.TYPE)
	@interface MyAnnotation{
		int val();
		String val2();
	}
	// example of Target annotation for interface, method , filed
	@Target({ElementType.TYPE,ElementType.FIELD, ElementType.METHOD})
	@interface MyAnnotation2{
		int val();
		String val2();
	}
	public static void main(String[] args) {
		//example to specify the annotation for class
		

	}

}

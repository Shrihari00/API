package com.wed;


public class Demo6SwitchWithEnum {
	enum Colors {
		RED, BLUE, ORANGE, BLACK
	}

	public static void main(String[] args) {
		Colors clr = Colors.ORANGE;
		switch (clr) {
		case RED:
			System.out.println("You have selected Red color");
			break;
		case BLUE:
			System.out.println("You have selected BLUE color");
			break;
		case ORANGE:
			System.out.println("You have selected ORANGE color");
			break;
		default:
			System.out.println("Wrong Choice");
			break;

		}

	}

}

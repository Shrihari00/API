package com.wed;



public enum Demo5ProductEnum {
	IPHONE12(50000),IPHONE13PRO(60000);
	int value;
	Demo5ProductEnum(int value){
		this.value=value;
	}
	public static void main(String[] args) {
		for(Demo5ProductEnum m: Demo5ProductEnum.values()) {
			System.out.println(m+"-"+m.value);
	}
	
	}
}

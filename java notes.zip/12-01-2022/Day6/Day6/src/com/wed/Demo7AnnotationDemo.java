package com.wed;

import java.util.ArrayList;

public class Demo7AnnotationDemo {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		ArrayList list = new ArrayList();
		MyDemoClass obj = new MyDemoClass();
		obj.display();
	}

}
abstract class myClass {
	public abstract void myMethod();
}
class myChildClass extends myClass{

	@Override
	public void myMethod() {
		// TODO Auto-generated method stub
		
	}
}
@Deprecated
class MyDemoClass{
	@Deprecated
	public void display() {
		
	}
	
}
